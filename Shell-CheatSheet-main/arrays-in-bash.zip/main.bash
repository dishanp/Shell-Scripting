echo "Enter array size";
read n;
declare -a arr;
i=0;
while [ $i -lt $n ]
do 
read x;
arr[i]=$x;
i=`expr $i + 1`;
done
echo ${arr[@]};
